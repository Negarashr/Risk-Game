import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { AngularFontAwesomeModule } from 'angular-font-awesome';

import { AppComponent } from './app.component';
import { WelcomeComponent } from './home/welcome.component';
import { RiskgameService } from './riskgame/riskgame.service';
import { FormsModule, ReactiveFormsModule }   from '@angular/forms';
import { RiskgameComponent } from './riskgame/riskgame.component';

@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent,
    RiskgameComponent
  ],
  providers:[
    RiskgameService
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,                            
    ReactiveFormsModule ,
    AngularFontAwesomeModule,
    RouterModule.forRoot([
        { path: 'welcome', component: WelcomeComponent },
        { path: '', redirectTo: 'welcome', pathMatch: 'full'},
        { path: '**', redirectTo: 'welcome', pathMatch: 'full'}
    ]),
    //ProductModule
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
