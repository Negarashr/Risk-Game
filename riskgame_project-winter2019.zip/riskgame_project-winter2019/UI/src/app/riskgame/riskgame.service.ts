import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { RiskgameBackendServer, userInput } from './riskgame';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/map';

@Injectable()
export class RiskgameService {
    private _productUrl = './api/products/products.json';
    constructor(private _http: HttpClient) { }

    assignCountriesToPlayers(input: string): Observable<any> {
        const assignCountriesToPlayersURL = RiskgameBackendServer.url + 'assignCountries?playersNumber=';

        console.log('assignCountriesToPlayers: ', input);
        return this._http.get(assignCountriesToPlayersURL + input)
            .map(data => data)
            .do(data => console.log('assignCountriesToPlayers Result: ' + JSON.stringify(data)))
            .catch(this.handleError);
    }

    // exchangeCard
    exchangeCard(playerNumber: string): Observable<any> {
        const exchangeCardURL = RiskgameBackendServer.url + 'reinforcement/exchangeCard?playerNumber=';

        console.log('exchangeCard: ', playerNumber);
        return this._http.get(exchangeCardURL + playerNumber)
            .map(data => data)
            .do(data => console.log('exchangeCard Result: ' + JSON.stringify(data)))
            .catch(this.handleError);
    }

    // positioningArmies
    positioningArmies(playerNumber: string, countryName: string, numberOfArmies: string): Observable<any> {
        const positioningArmiesURL = RiskgameBackendServer.url + 'reinforcement/positioningArmies?playerNumber=';

        console.log('positioningArmies: ', playerNumber, countryName, numberOfArmies);
        return this._http.get(positioningArmiesURL + playerNumber + "&countryName=" + countryName + "&numberOfArmies=" + numberOfArmies)
            .map(data => data)
            .do(data => console.log('positioningArmies Result: ' + JSON.stringify(data)))
            .catch(this.handleError);
    }

    // attack
    attack(playerNumber: string, attackingCountry: string, defendingCountry: string, numberOfArmies: string): Observable<any> {
        const attckURL = RiskgameBackendServer.url + 'attack?playerNumber=';

        console.log('attack: ', playerNumber, attackingCountry, defendingCountry, numberOfArmies);
        return this._http.get(attckURL + playerNumber + "&attackingCountry=" + attackingCountry + "&defendingCountry=" + defendingCountry + "&numberOfArmies=" + numberOfArmies)
            .map(data => data)
            .do(data => console.log('attack Result: ' + JSON.stringify(data)))
            .catch(this.handleError);
    }

    // attackAllout
    attackAllOut(playerNumber: string, attackingCountry: string, defendingCountry: string): Observable<any> {
        const attckURL = RiskgameBackendServer.url + 'attackAllOut?playerNumber=';

        console.log('attackAllOut: ', playerNumber, attackingCountry, defendingCountry);
        return this._http.get(attckURL + playerNumber + "&attackingCountry=" + attackingCountry + "&defendingCountry=" + defendingCountry)
            .map(data => data)
            .do(data => console.log('attackAllOut Result: ' + JSON.stringify(data)))
            .catch(this.handleError);
    }

    // fortification
    fortification(playerNumber: string, sourceCountry: string, destinationCountry: string, numberOfArmies: string): Observable<any> {
        const pfortificationURL = RiskgameBackendServer.url + 'fortification?playerNumber=';

        console.log('fortification: ', playerNumber, sourceCountry, destinationCountry, numberOfArmies);
        return this._http.get(pfortificationURL + playerNumber + "&sourceCountry=" + sourceCountry + "&destinationCountry=" + destinationCountry + "&numberOfArmies=" + numberOfArmies)
            .map(data => data)
            .do(data => console.log('fortification Result: ' + JSON.stringify(data)))
            .catch(this.handleError);
    }

    // skip
    skip(playerNumber: string): Observable<any> {
        const skipURL = RiskgameBackendServer.url + 'skip?playerNumber=';

        console.log('skip: ', playerNumber);
        return this._http.get(skipURL + playerNumber)
            .map(data => data)
            .do(data => console.log('Skip Result: ' + JSON.stringify(data)))
            .catch(this.handleError);
    }

    // createUserDefineMap
    createUserDefineMap(mapContent: string): Observable<any> {

        const loadMapUrl = RiskgameBackendServer.url + 'loadMap?mapContent=';

        console.log('createUserDefineMap: ', loadMapUrl + mapContent + "&filePath=");
        return this._http.get(loadMapUrl + mapContent + "&filePath=")
            .map(data => data)
            .do(data => console.log('createUserDefineMap Result: ' + JSON.stringify(data)))
            .catch(this.handleError);
    }

    // load Default Map
    loadDefaultMap(filePath: string): Observable<any> {

        const loadMapUrl = RiskgameBackendServer.url + 'loadMap?mapContent=';

        console.log('loadDefualtMap: ', loadMapUrl + '' + '&filePath=' + filePath);
        return this._http.get(loadMapUrl + loadMapUrl + '' + '&filePath=' + filePath)
            .map(data => data)
            .do(data => console.log('loadDefualtMap Result: ', JSON.stringify(data)))
            .catch(this.handleError);
    }

    // get Existing Maps
    getExistingMaps(): Observable<any> {

        const getExistingMapsURL = RiskgameBackendServer.url + 'getExistingMaps';

        console.log('getExistingMaps');
        return this._http.get(getExistingMapsURL)
            .map(data => data)
            .do(data => console.log('getExistingMaps Result: ', JSON.stringify(data)))
            .catch(this.handleError);
    }

    // load Existing Map
    loadExistingMap(filePath: string): Observable<any> {

        const loadMapUrl = RiskgameBackendServer.url + 'loadMap?mapContent=';

        console.log('loadExistingMap: ', loadMapUrl + '' + '&filePath=' + filePath);
        return this._http.get(loadMapUrl + '' + '&filePath=' + filePath)
            .map(data => data)
            .do(data => console.log('loadExistingMap Result: ', JSON.stringify(data)))
            .catch(this.handleError);
    }

    // startSingle Mode
    startSingleMode(input: userInput): Observable<any> {

        let startSingleModeUrl = RiskgameBackendServer.url + 'singleMode?';
        startSingleModeUrl += 'gameMap1=' + input.gameMap1;
        startSingleModeUrl += '&playerType1=' + input.playerType1;
        startSingleModeUrl += '&playerType2=' + input.playerType2;
        startSingleModeUrl += '&playerType3=' + input.playerType3;
        startSingleModeUrl += '&playerType4=' + input.playerType4;

        console.log('start SingleMode');

        return this._http.get(startSingleModeUrl)
            .map(data => data)
            .do(data => console.log('startS ingleMode Result: ', JSON.stringify(data)))
            .catch(this.handleError);
    }

    // start Tournament
    startTournament(input: userInput): Observable<any> {

        let startTournamentUrl = RiskgameBackendServer.url + 'tournament?';
        startTournamentUrl += 'gameMap1=' + input.gameMap1;
        startTournamentUrl += '&gameMap2=' + input.gameMap2;
        startTournamentUrl += '&gameMap3=' + input.gameMap3;
        startTournamentUrl += '&gameMap4=' + input.gameMap4;
        startTournamentUrl += '&gameMap5=' + input.gameMap5;
        startTournamentUrl += '&playerType1=' + input.playerType1;
        startTournamentUrl += '&playerType2=' + input.playerType2;
        startTournamentUrl += '&playerType3=' + input.playerType3;
        startTournamentUrl += '&playerType4=' + input.playerType4;
        startTournamentUrl += '&numberOfGames=' + input.numberOfGames;
        startTournamentUrl += '&numberOfTurns=' + input.numberOfTurns;

        console.log('start Tournament');

        return this._http.get(startTournamentUrl)
            .map(data => data)
            .do(data => console.log('start Tournament Result: ', JSON.stringify(data)))
            .catch(this.handleError);
    }

    // save game
    saveGame(): Observable<any> {

        const saveGameUrl = RiskgameBackendServer.url + 'saveGame';

        console.log('saveGameUrl: ', saveGameUrl);
        return this._http.get(saveGameUrl)
            .map(data => data)
            .do(data => console.log('saveGameUrl Result: ', JSON.stringify(data)))
            .catch(this.handleError);
    }

    // load game
    loadGame(existingGame: string): Observable<any> {

        const loadGameUrl = RiskgameBackendServer.url + 'loadGame?gameToLoad=' + existingGame;

        console.log('loadGameUrl: ', loadGameUrl);
        return this._http.get(loadGameUrl)
            .map(data => data)
            .do(data => console.log('loadGame Result: ', JSON.stringify(data)))
            .catch(this.handleError);
    }

    // get Existing Saved Games
    getExistingSavedGames(): Observable<any> {

        const getExistingSavedGamesUrl = RiskgameBackendServer.url + 'getExistingSavedGames';

        console.log('getExistingSavedGames');
        return this._http.get(getExistingSavedGamesUrl)
            .map(data => data)
            .do(data => console.log('getExistingSavedGames Result: ', JSON.stringify(data)))
            .catch(this.handleError);
    }

    // auto Move
    autoMove(playerNumber: string): Observable<any> {
        const autoMoveUrl = RiskgameBackendServer.url + 'autoMove?playerNumber=';

        console.log('autoMove: ', playerNumber);
        return this._http.get(autoMoveUrl + playerNumber)
            .map(data => data)
            .do(data => console.log('autoMove Result: ' + JSON.stringify(data)))
            .catch(this.handleError);
    }

    // get Domination View
    getDominationView(callTime: string): Observable<any> {

        const viewPhaseDominationUrl = RiskgameBackendServer.url + 'viewPhaseDomination?callTime=' + callTime;
        return this._http.get(viewPhaseDominationUrl)
            .map(data => data)
        // .do(data => console.log('viewPhaseDominationUrl Result: ', JSON.stringify(data)))
        // .catch(this.handleError);
    }

    // get Phase View
    getPhaseView(callTime: string): Observable<any> {
        const phaseViewUrl = RiskgameBackendServer.url + 'viewPhasePlayer?callTime=' + callTime;
        return this._http.get(phaseViewUrl)
            .map(data => data)

    }

    private handleError(err: HttpErrorResponse) {

        console.error('HttpErrorResponse:', err);
        let errorMessage = '';
        if (err.error instanceof Error) {
            // A client-side or network error occurred. Handle it accordingly.
            // errorMessage = `An error occurred: ${err.error.message}`;
            errorMessage = `An error occurred: ${err.error}`;
        } else {
            // The backend returned an unsuccessful response code.
            // The response body may contain clues as to what went wrong,
            // errorMessage = `Server returned code: ${err.status}, error message is: ${err.message}`;
            errorMessage = `An error occurred: ${err.error}`;
        }
        console.error(errorMessage);
        return Observable.throw(errorMessage);
    }
}
