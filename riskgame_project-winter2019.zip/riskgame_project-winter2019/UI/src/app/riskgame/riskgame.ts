export const RiskgameBackendServer = {
  url: 'http://localhost:8080/',
}

export class Riskgame {
  result: string;
  javaResult: string;
  error: string;
}

export class userInput {
  userDeifneMap: string;
  userInput: string;
  methodName: string;
  cardNumber: string;
  countryNamePositioning: string;
  numberOfArmiesPositioning: string;
  attackingCountry: string;
  defendingCountry: string;
  numberOfArmiesAttacking: string;
  sourceCountryFortification: string;
  destinationCountryFortification: string;
  numberOfArmiesFortification: string;
  mapChoosedFromExisting: string;
  userEditedMapFromExisting: string;
  conqueredCountry: string;
  armiesToMoveToconqueredCountry: string;
  gameMap1: string;
  gameMap2: string;
  gameMap3: string;
  gameMap4: string;
  gameMap5: string;
  playerType1: string;
  playerType2: string;
  playerType3: string;
  playerType4: string;
  numberOfGames: string;
  numberOfTurns: string;
  gameChoosedFromExisting: string;
}

export class Player {
  playerTurnNumber: string;
  playerName: string;
  playerId: number;
  army: number;
  card: number;
  timesAlreadyExchangedCardsForArmy: number;
  playersCount: number;
  countries: [Country];
  playerStatus: string;
  playerType: string;
}

export class Country {
  name: string;
  countryId: number;
  armies: number;
  linkedCountries: [string]
}

export class AttackResult {
  attackerDice;
  defenderDice;
  initialAttackerArmy = 0;
  deadAttackerArmy = 0;
  survivedAttackerArmy = 0;
  initialDefenderArmy = 0;
  deadDefenderArmy = 0;
  survivedDefenderArmy = 0;
  attackingCountry: string;
  conqueredCountry: string;
}

export class Dice {
  results = [];
  diceCount = 0;
}

export class LoadMapResult {
  fileName: string;
  creationTime: string;
  existingMaps: Array<string>;
  requestedMapContent: string;
}

export class PlayersMapOwnership {
  playerName: string;
  percentage: string;
}

export class PlayersContinentOwnership {
  playerName: string;
  continents: Array<string>;
}

export class PlayersTotalArmy {
  playerName: string;
  armies: string;
}

export class TournamentResult {
  mapName: string;
  gameWinnerPairs: GameWinnerPair[];
}

export class GameWinnerPair {
  gameNumber: string
  winner: string;
}

export const MAP_SMAPLE = {
  map: ' e.g. \n'
    + 'continent1=Control Value' + '\n'
    + 'continent2=Control Value' + '\n'
    + '\n' + 'country1,positionX,positionY,continent1,country2'
    + '\n' + 'country2,positionX,positionY,continent2,country1',
}
