import { Component, OnInit } from '@angular/core';
import {
    Riskgame, userInput, Player, Country, AttackResult, Dice,
    LoadMapResult, MAP_SMAPLE, PlayersContinentOwnership, PlayersMapOwnership,
    PlayersTotalArmy, RiskgameBackendServer, TournamentResult, GameWinnerPair
} from './riskgame';
import { RiskgameService } from './riskgame.service';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import * as Stomp from 'stompjs';
import * as SockJS from 'sockjs-client';


declare var require: any;

@Component({
    selector: 'riskgame',
    templateUrl: './riskgame.component.html',
    styleUrls: ['./riskgame.component.css']
})
export class RiskgameComponent implements OnInit {
    private stompClient = null;
    mapTypesToLoad: {
        'defaultMap', 'newMap', 'editExistingMap', 'tournament', 'singleMode', 'load'
    };
    playerTypes = ['Aggressive', 'Benevolent', 'Random', 'Cheater'];
    singleModePlayerTypes = ['Human', 'Aggressive', 'Benevolent', 'Random', 'Cheater'];
    userChoiceForLoadMap: string = 'none';
    errorMessage: string;
    successMessage: string;
    mapLoadCompleted = false;
    isGameStartedUp = false;
    showAttackResult = false;
    model = new userInput();
    attackResult = new AttackResult();
    loadMapResult = new LoadMapResult();
    players = new Array<Player>();
    viewPhasePlayer: Player;
    playersContinentOwnershipList = new Array<PlayersContinentOwnership>();
    playersTotalArmyList = new Array<PlayersTotalArmy>();
    playersMapOwnershipList = new Array<PlayersMapOwnership>();
    tournamentResultList = new Array<TournamentResult>();

    constructor(private _riskgameService: RiskgameService) {

    }

    ngOnInit(): void {
        this.getDominationView('initCall');
        this.getPhaseView('initCall');

        setInterval(() => {
            this.getDominationView('intervalCall');
        }, 1398);

        setInterval(() => {
            this.getPhaseView('intervalCall');
        }, 1398);

        // this.connectAndSubscribeForDominationView();
        // this.connectAndSubscribeForViewPhase();
    }

    diagnose() {
        console.log(JSON.stringify(this.model));
    }

    choosingMap(mapType: string): void {
        this.clearMessages();
        this.userChoiceForLoadMap = mapType;
        this.model.userDeifneMap = MAP_SMAPLE.map;
        console.log('user map type is:', this.userChoiceForLoadMap);
        if (this.userChoiceForLoadMap == 'defaultMap') {
            this.loadDefaultMap();
        } else if (this.userChoiceForLoadMap == 'editExistingMap') {
            this.model.userDeifneMap = null; // Reset example for new map
            this.getExistingMaps();
        } else if (this.userChoiceForLoadMap == 'tournament') {
            this.getExistingMaps();
        } else if (this.userChoiceForLoadMap == 'singleMode') {
            this.getExistingMaps();
        } else if (this.userChoiceForLoadMap == 'load') {
            this.getExistingSavedGames();
        }
    }

    loadExistingMap(): void {
        this.clearMessages();
        let mapName = '';
        if (this.model.mapChoosedFromExisting.indexOf('\\') !== -1) {
            mapName = this.model.mapChoosedFromExisting.replace('\\', '%5C');
        }
        if (this.model.mapChoosedFromExisting.indexOf('/') !== -1) {
            mapName = this.model.mapChoosedFromExisting.replace('/', '%2F');
        }
        console.log('user map choosed:', this.model.mapChoosedFromExisting, mapName);
        this._riskgameService.loadExistingMap(mapName)
            .subscribe(
                data => {
                    console.log('loadExistingMap', data);
                    this.model.userEditedMapFromExisting = data['requestedMapContent'];
                },
                error => this.errorMessage = error, // error path
                () => {
                    this.mapLoadCompleted = false;
                    this.isGameStartedUp = false;
                }
            );
    }

    loadDefaultMap(): void {

        this.clearMessages();
        this._riskgameService.loadDefaultMap('DEFAULT_MAP_PATH')
            .subscribe(
                data => {
                    console.log('loadDefaultMap', data);
                    this.successMessage = 'Default Map loaded Successfully!';
                },
                error => this.errorMessage = error, // error path
                () => {
                    this.mapLoadCompleted = true;
                    this.isGameStartedUp = false;
                }
            );
    }

    getExistingMaps(): void {
        this.clearMessages();
        this.loadMapResult = new LoadMapResult();
        this._riskgameService.getExistingMaps()
            .subscribe(
                data => {
                    console.log('getExistingMaps', data);
                    this.loadMapResult = data;
                },
                error => this.errorMessage = error, // error path
                () => {
                    this.mapLoadCompleted = false;
                    this.isGameStartedUp = false;
                }
            );
    }

    assignCountriesToPlayers(): void {
        this.clearMessages();
        let userInput: any = this.model.userInput;
        this._riskgameService.assignCountriesToPlayers(userInput)
            .subscribe(
                data => {
                    this.players = [];
                    for (let key in data) {
                        console.log('key: ', key, ', value: ', data[key]);
                        if (data[key] instanceof Object) {

                            this.players.push(data[key]);
                            const index: number = +key - 1;
                            this.players[index].playerTurnNumber = key;
                            console.log(this.players[index]);
                        }
                    }
                },
                error => this.errorMessage = error, // error path
                () => {
                    this.draw(this.extractCountries());
                    this.isGameStartedUp = true;
                }
            );
    }

    private draw(countries: Array<Country>): void {

        let alreadyExistedEdges = new Array<string>();
        let Dracula = require('graphdracula');

        let Graph = Dracula.Graph;
        let Renderer = Dracula.Renderer.Raphael;
        let Layout = Dracula.Layout.Spring;

        let graph = new Graph();

        countries.forEach(country => {
            country.linkedCountries.forEach(linkedCountry => {
                const edgeIntex1 = country.name + linkedCountry;
                const edgeIntex2 = linkedCountry + country.name;
                if (alreadyExistedEdges.indexOf(edgeIntex1) === -1 && alreadyExistedEdges.indexOf(edgeIntex2) === -1) {
                    alreadyExistedEdges.push(edgeIntex1);
                    alreadyExistedEdges.push(edgeIntex2);
                    console.log(country.name, linkedCountry);
                    graph.addEdge(country.name, linkedCountry);
                }

            });
        });
        //graph.addNode('id35', {
        // label: 'meat\nand\ngreed' ,
        /* filling the shape with a color makes it easier to be dragged */
        // render: render
        //  });
        let layout = new Layout(graph)
        let renderer = new Renderer('#paper', graph, 500, 500)
        renderer.draw()
    }

    extractCountries(): Array<Country> {
        const allCountriesArray = new Array();
        const allCountries = new Array<Country>();
        this.players.forEach(player => {
            allCountriesArray.push(player.countries);
        });
        allCountriesArray.forEach(country => {
            country.forEach(element => {
                allCountries.push(element);
            });

        })
        console.log('all Countries:', allCountries);
        return allCountries;
    }

    mapClicked(event: any): void {
        try {
            console.log('map clicked', event, event.target.nextElementSibling.childNodes[0].childNodes[0].data);
            this.model.countryNamePositioning = event.target.nextElementSibling.childNodes[0].childNodes[0].data;
        } catch (e) {
            console.log('NO countries clicked!');
        }

    }

    exchangeCard(playerNumber: string): void {
        this.clearMessages();
        this._riskgameService.exchangeCard(playerNumber)
            .subscribe(
                data => {
                    this.players = new Array<Player>();
                    for (let key in data) {
                        console.log('key: ', key, ', value: ', data[key]);
                        if (data[key] instanceof Object) {

                            this.players.push(data[key]);
                            const index: number = +key - 1;
                            this.players[index].playerTurnNumber = key;
                            console.log(this.players[index]);
                        }
                    }
                },
                error => this.errorMessage = error,
                () => {
                    this.resetInputModel();
                }
            );
    }

    positioningArmies(playerNumber: string): void {
        this.clearMessages();
        const countryName = this.model.countryNamePositioning;
        const numberOfArmies = this.model.numberOfArmiesPositioning;
        this._riskgameService.positioningArmies(playerNumber, countryName, numberOfArmies)
            .subscribe(
                data => {
                    this.players = new Array<Player>();
                    for (let key in data) {
                        console.log('key: ', key, ', value: ', data[key]);
                        if (data[key] instanceof Object) {

                            this.players.push(data[key]);
                            const index: number = +key - 1;
                            this.players[index].playerTurnNumber = key;
                            console.log(this.players[index]);
                        }
                    }
                },
                error => this.errorMessage = error,
                () => {
                    this.resetInputModel();
                }
            );
    }

    conqueredCountryPositioningArmies(playerNumber: string): void {
        this.clearMessages();
        const countryName = this.attackResult.conqueredCountry;
        const numberOfArmies = this.model.armiesToMoveToconqueredCountry;
        this._riskgameService.positioningArmies(playerNumber, countryName, numberOfArmies)
            .subscribe(
                data => {
                    this.showAttackResult = false;
                    this.players = new Array<Player>();
                    for (let key in data) {
                        console.log('key: ', key, ', value: ', data[key]);
                        if (data[key] instanceof Object) {

                            this.players.push(data[key]);
                            const index: number = +key - 1;
                            this.players[index].playerTurnNumber = key;
                            console.log(this.players[index]);
                        }
                    }
                },
                error => this.errorMessage = error,
                () => {
                    this.attackResult = new AttackResult();
                    this.resetInputModel();
                }
            );
    }

    attack(playerNumber: string): void {
        this.clearMessages();
        const attackingCountry = this.model.attackingCountry;
        const defendingCountry = this.model.defendingCountry;
        const numberOfArmiesAttacking = this.model.numberOfArmiesAttacking;
        this._riskgameService.attack(playerNumber, attackingCountry, defendingCountry, numberOfArmiesAttacking)
            .subscribe(
                data => {
                    this.showAttackResult = true;
                    this.players = new Array<Player>();
                    this.attackResult = new AttackResult();

                    const playersAfterAttack = data.players;
                    for (let key in playersAfterAttack) {
                        console.log('key: ', key, ', value: ', playersAfterAttack[key]);
                        if (playersAfterAttack[key] instanceof Object) {

                            this.players.push(playersAfterAttack[key]);
                            const index: number = +key - 1;
                            this.players[index].playerTurnNumber = key;
                            console.log(this.players[index]);
                        }
                    }
                    this.attackResult.initialAttackerArmy = data.initialAttackerArmy;
                    this.attackResult.deadAttackerArmy = data.deadAttackerArmy;
                    this.attackResult.survivedAttackerArmy = data.survivedAttackerArmy;
                    this.attackResult.initialDefenderArmy = data.initialDefenderArmy;
                    this.attackResult.deadDefenderArmy = data.deadDefenderArmy;
                    this.attackResult.survivedDefenderArmy = data.survivedDefenderArmy;
                    this.attackResult.attackerDice = data.attackerDice;
                    this.attackResult.defenderDice = data.defenderDice;
                    this.attackResult.attackingCountry = data.attackingCountry;
                    this.attackResult.conqueredCountry = data.conqueredCountry;
                },
                error => this.errorMessage = error,
                () => {
                    this.resetInputModel();
                }
            );
    }

    attackAllOut(playerNumber: string): void {
        this.clearMessages();
        const attackingCountry = this.model.attackingCountry;
        const defendingCountry = this.model.defendingCountry;
        this._riskgameService.attackAllOut(playerNumber, attackingCountry, defendingCountry)
            .subscribe(
                data => {
                    this.showAttackResult = true;
                    this.players = new Array<Player>();
                    this.attackResult = new AttackResult();

                    const playersAfterAttack = data.players;
                    for (let key in playersAfterAttack) {
                        console.log('key: ', key, ', value: ', playersAfterAttack[key]);
                        if (playersAfterAttack[key] instanceof Object) {

                            this.players.push(playersAfterAttack[key]);
                            const index: number = +key - 1;
                            this.players[index].playerTurnNumber = key;
                            console.log(this.players[index]);
                        }
                    }
                    this.attackResult.initialAttackerArmy = data.initialAttackerArmy;
                    this.attackResult.deadAttackerArmy = data.deadAttackerArmy;
                    this.attackResult.survivedAttackerArmy = data.survivedAttackerArmy;
                    this.attackResult.initialDefenderArmy = data.initialDefenderArmy;
                    this.attackResult.deadDefenderArmy = data.deadDefenderArmy;
                    this.attackResult.survivedDefenderArmy = data.survivedDefenderArmy;
                    this.attackResult.attackerDice = data.attackerDice;
                    this.attackResult.defenderDice = data.defenderDice;
                    this.attackResult.attackingCountry = data.attackingCountry;
                    this.attackResult.conqueredCountry = data.conqueredCountry;
                },
                error => this.errorMessage = error,
                () => {
                    this.resetInputModel();
                }
            );
    }

    fortification(playerNumber: string): void {
        this.clearMessages();
        const sourceCountry = this.model.sourceCountryFortification;
        const destinationCountry = this.model.destinationCountryFortification;
        const numberOfArmies = this.model.numberOfArmiesFortification;
        this._riskgameService.fortification(playerNumber, sourceCountry, destinationCountry, numberOfArmies)
            .subscribe(
                data => {
                    this.showAttackResult = false;
                    this.players = new Array<Player>();
                    for (let key in data) {
                        console.log('key: ', key, ', value: ', data[key]);
                        if (data[key] instanceof Object) {

                            this.players.push(data[key]);
                            const index: number = +key - 1;
                            this.players[index].playerTurnNumber = key;
                            console.log(this.players[index]);
                        }
                    }
                },
                error => this.errorMessage = error,
                () => {
                    this.resetInputModel();
                }
            );
    }

    skip(playerNumber: string): void {
        this.clearMessages();
        this._riskgameService.skip(playerNumber)
            .subscribe(
                data => {
                    this.players = new Array<Player>();
                    for (let key in data) {
                        console.log('key: ', key, ', value: ', data[key]);
                        if (data[key] instanceof Object) {

                            this.players.push(data[key]);
                            const index: number = +key - 1;
                            this.players[index].playerTurnNumber = key;
                            console.log(this.players[index]);
                        }
                    }
                },
                error => this.errorMessage = error,
                () => {
                    this.resetInputModel();
                }
            );
    }

    resetInputModel(): void {
        this.model = new userInput();
    }

    // Create Map based on user input
    createUserDefineMap(): void {
        this.clearMessages();
        let mapToSend: string;
        if (this.model.userDeifneMap !== null && typeof this.model.userDeifneMap !== 'undefined') {
            mapToSend = this.model.userDeifneMap.trim();
            this.model.userDeifneMap = '';
        } else {
            mapToSend = this.model.userEditedMapFromExisting.trim();
            this.model.userEditedMapFromExisting = '';
        }
        console.log('createUserDefineMap', mapToSend);
        let mapItems = mapToSend.split('\n');
        mapToSend = '';
        mapItems.forEach(s => {
            mapToSend = mapToSend + (s + '%0A');

        });
        console.log('mapTo Send ::: ', mapToSend);
        this._riskgameService.createUserDefineMap(mapToSend)
            .subscribe(
                data => {
                    console.log(data);
                    this.successMessage = 'Map loaded Successfully, name of saved map: ' + data['fileName'];
                },
                error => this.errorMessage = error,
                () => {
                    this.mapLoadCompleted = true;
                    this.isGameStartedUp = false;
                    this.resetInputModel();
                }
            );
    }
    clearMessages(): void {
        this.errorMessage = '';
        this.successMessage = '';
    }

    getPhaseView(callTime: string): void {
        this._riskgameService.getPhaseView(callTime)
            .subscribe(
                data => {
                    if (data) {
                        this.viewPhasePlayer = data;
                    }
                },
                error => '',
                () => {
                }
            );
    }

    getDominationView(callTime: string): void {
        this._riskgameService.getDominationView(callTime)
            .subscribe(
                data => {
                    if (data) {

                        this.playersMapOwnershipList = [];
                        this.playersContinentOwnershipList = [];
                        this.playersTotalArmyList = [];

                        for (let key in data['playersMapOwnership']) {
                            let tmp = new PlayersMapOwnership();
                            tmp.playerName = key;
                            tmp.percentage = data['playersMapOwnership'][key];
                            this.playersMapOwnershipList.push(tmp);
                        }
                        for (let key in data['playersContinentOwnership']) {
                            let tmp = new PlayersContinentOwnership();
                            tmp.playerName = key;
                            tmp.continents = data['playersContinentOwnership'][key];
                            this.playersContinentOwnershipList.push(tmp);
                        }
                        for (let key in data['playersTotalArmy']) {
                            let tmp = new PlayersTotalArmy();
                            tmp.playerName = key;
                            tmp.armies = data['playersTotalArmy'][key];
                            this.playersTotalArmyList.push(tmp);
                        }
                    }
                },
                error => '',
                () => {
                }
            );
    }


    connectAndSubscribeForDominationView() {
        const socket = new SockJS(RiskgameBackendServer.url + 'gs-guide-websocket');
        this.stompClient = Stomp.over(socket);
        const _this = this;

        _this.stompClient.connect({}, function (frame) {
            console.log('Connected: ' + socket);

            _this.stompClient.subscribe('/topic/dominationView', function (data) {

                _this.playersMapOwnershipList = [];
                _this.playersContinentOwnershipList = [];
                _this.playersTotalArmyList = [];

                console.log('Domination View FROM WEBSOCKET PUSHED', data);
                const dominationView = JSON.parse(data['body']);
                for (let key in dominationView['playersMapOwnership']) {
                    // console.log('key: ', key, ', _this.dominationView[key]: ', dominationView['playersMapOwnership'][key]);
                    let tmp = new PlayersMapOwnership();
                    tmp.playerName = key;
                    tmp.percentage = dominationView['playersMapOwnership'][key];
                    _this.playersMapOwnershipList.push(tmp);
                }
                for (let key in dominationView['playersContinentOwnership']) {
                    // console.log('key: ', key, ', _this.dominationView[key]: ', dominationView['playersContinentOwnership'][key]);
                    let tmp = new PlayersContinentOwnership();
                    tmp.playerName = key;
                    tmp.continents = dominationView['playersContinentOwnership'][key];
                    _this.playersContinentOwnershipList.push(tmp);
                }
                for (let key in dominationView['playersTotalArmy']) {
                    // console.log('key: ', key, ', _this.dominationView[key]: ', dominationView['playersTotalArmy'][key]);
                    let tmp = new PlayersTotalArmy();
                    tmp.playerName = key;
                    tmp.armies = dominationView['playersTotalArmy'][key];
                    _this.playersTotalArmyList.push(tmp);
                }
            });
        });

    }
    connectAndSubscribeForViewPhase() {
        const socket = new SockJS(RiskgameBackendServer.url + 'gs-guide-websocket');
        this.stompClient = Stomp.over(socket);
        const _this = this;

        _this.stompClient.connect({}, function (frame) {
            console.log('Connected: ' + socket);
            _this.stompClient.subscribe('/topic/viewPhase', function (data) {
                console.log('viewPhase FROM WEBSOCKET PUSHED', data);
                _this.viewPhasePlayer = JSON.parse(data['body']);
            });
        });
    }

    startTournament(): void {
        console.log('startTournament');
        this.clearMessages();
        this.tournamentResultList = []

        this._riskgameService.startTournament(this.model)
            .subscribe(
                data => {
                    for (let key in data) {
                        console.log('key: ', key, ', value: ', data[key]);
                        if (data[key] instanceof Object) {
                            this.tournamentResultList.push(data[key]);
                        }
                    }
                },
                error => this.errorMessage = error,
                () => {
                    this.mapLoadCompleted = true;
                    this.isGameStartedUp = true;
                    this.resetInputModel();
                }
            );
    }

    startSingleMode(): void {
        console.log('startSingleMode');
        this.clearMessages();
        this._riskgameService.startSingleMode(this.model)
            .subscribe(
                data => {
                    this.players = [];
                    for (let key in data) {
                        console.log('key: ', key, ', value: ', data[key]);
                        if (data[key] instanceof Object) {

                            this.players.push(data[key]);
                            const index: number = +key - 1;
                            this.players[index].playerTurnNumber = key;
                        }
                    }
                },
                error => this.errorMessage = error,
                () => {
                    this.draw(this.extractCountries());
                    this.mapLoadCompleted = true;
                    this.isGameStartedUp = true;
                    this.resetInputModel();
                }
            );
    }

    save(): void {
        this.clearMessages();
        this._riskgameService.saveGame()
            .subscribe(
                data => {
                    console.log('save', data);
                    this.successMessage = 'Game Saved Successfully, name of saved Game: ' + data['fileName'];
                },
                error => this.errorMessage = error, // error path
                () => {
                    console.log('save finished');
                }
            );
    }

    getExistingSavedGames(): void {
        this.clearMessages();
        this.loadMapResult = new LoadMapResult();
        this._riskgameService.getExistingSavedGames()
            .subscribe(
                data => {
                    console.log('getExistingSavedGames', data);
                    this.loadMapResult = data;
                },
                error => this.errorMessage = error, // error path
                () => {
                    this.mapLoadCompleted = false;
                    this.isGameStartedUp = false;
                }
            );
    }
    load(): void {
        console.log('load');
        this.clearMessages();
        this._riskgameService.loadGame(this.model.gameChoosedFromExisting)
            .subscribe(
                data => {
                    this.players = [];
                    for (let key in data) {
                        console.log('key: ', key, ', value: ', data[key]);
                        if (data[key] instanceof Object) {

                            this.players.push(data[key]);
                            const index: number = +key - 1;
                            this.players[index].playerTurnNumber = key;
                        }
                    }
                },
                error => this.errorMessage = error, // error path
                () => {
                    this.draw(this.extractCountries());
                    this.isGameStartedUp = true;
                    this.mapLoadCompleted = true;
                }
            );
    }
    autoMove(playerNumber: string): void {
        this.clearMessages();
        this._riskgameService.autoMove(playerNumber)
            .subscribe(
                data => {
                    // this.showAttackResult = false;
                    this.players = new Array<Player>();
                    for (let key in data) {
                        console.log('key: ', key, ', value: ', data[key]);
                        if (data[key] instanceof Object) {

                            this.players.push(data[key]);
                            const index: number = +key - 1;
                            this.players[index].playerTurnNumber = key;
                            console.log(this.players[index]);
                        }
                    }
                },
                error => this.errorMessage = error,
                () => {
                    this.resetInputModel();
                }
            );
    }
}
