/* SystemJS module definition */
declare var module: NodeModule;
declare var Dracula: any;
interface NodeModule {
  id: string;
}
